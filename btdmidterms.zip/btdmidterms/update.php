<?php
include 'db.php';

$id = $_POST['id'];
$title = $_POST['title'];
$description = $_POST['description'];
$status = $_POST['status'];

$sql = "UPDATE tasks SET 
        title='$title',
        description='$description',
        status='$status'
        WHERE id=$id";

$conn->query($sql);
?>