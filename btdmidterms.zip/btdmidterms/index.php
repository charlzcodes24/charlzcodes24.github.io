<!DOCTYPE html>
<html>
<head>
    <title>To-Do List App</title>
    <link rel="stylesheet" href="style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            padding: 30px;
            width: 100%;
            max-width: 500px;
        }
        h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }
        input, textarea {
            width: 100%;
            padding: 12px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-family: inherit;
            font-size: 14px;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-bottom: 20px;
        }
        button:hover {
            background: #764ba2;
        }
        #taskList {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>To-Do List</h2>
    <input type="text" id="title" placeholder="Task title">
    <textarea id="description" placeholder="Task description"></textarea>
    <button onclick="addTask()">Add Task</button>
    <div id="taskList"></div>
</div>

<script src="script.js"></script>

</body>
</html>