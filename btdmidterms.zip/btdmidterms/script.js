document.addEventListener("DOMContentLoaded", loadTasks);

function loadTasks() {
  fetch("fetch.php")
    .then((response) => response.text())
    .then((data) => {
      document.getElementById("taskList").innerHTML = data;
    });
}

function addTask() {
  let title = document.getElementById("title").value;
  let description = document.getElementById("description").value;

  fetch("add.php", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `title=${title}&description=${description}`,
  }).then(() => {
    loadTasks();
    document.getElementById("title").value = "";
    document.getElementById("description").value = "";
  });
}

function deleteTask(id) {
  fetch("delete.php?id=" + id).then(() => loadTasks());
}

function updateTask(id) {
  let newTitle = prompt("Enter new title:");
  let newDescription = prompt("Enter new description:");
  let newStatus = prompt("Enter status (Pending/Completed):");

  fetch("update.php", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `id=${id}&title=${newTitle}&description=${newDescription}&status=${newStatus}`,
  }).then(() => loadTasks());
}
