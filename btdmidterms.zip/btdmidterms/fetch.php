<?php
include 'db.php';

$result = $conn->query("SELECT * FROM tasks ORDER BY created_at DESC");

while ($row = $result->fetch_assoc()) {
    echo "<div class='task'>";
    echo "<h3>{$row['title']}</h3>";
    echo "<p>{$row['description']}</p>";
    echo "<p>Status: {$row['status']}</p>";
    echo "<button onclick='updateTask({$row['id']})'>Edit</button>";
    echo "<button onclick='deleteTask({$row['id']})'>Delete</button>";
    echo "</div><hr>";
}
?>